package _17Generics.JarOfT;

public class Main {




    
}
